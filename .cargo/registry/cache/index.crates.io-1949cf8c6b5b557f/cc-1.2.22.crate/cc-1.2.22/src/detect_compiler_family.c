#ifdef __clang__
#pragma message "clang"
#endif

#ifdef __GNUC__
#pragma message "gcc"
#endif

#ifdef __EMSCRIPTEN__
#pragma message "emscripten"
#endif

#ifdef __VXWORKS__
#pragma message "VxWorks"
#endif
